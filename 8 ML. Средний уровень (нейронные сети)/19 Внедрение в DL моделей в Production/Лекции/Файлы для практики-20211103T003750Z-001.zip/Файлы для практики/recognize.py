import sys
import json
import requests
import numpy as np
from PIL import Image

# Функция для изменения размера изображения
def resize(img, new_size):
    img = Image.fromarray(img)
    img = img.resize(new_size)
    return np.array(img)

# Функция для подготовки одного изображения к инференсу
# Приведение в нужный диапазон и размер
def prepare_digit(img):
    img = resize(img, (28, 28))
    img = img.astype(np.float32)/255
    if len(img.shape) > 2:
        img = np.mean(img, axis=2)
    img = (1. - img).astype(np.float32)
    img = np.reshape(img, (28, 28, 1))
    return img

# Функция для подготовки входа в нейронную сеть
# Вход в нейронную сеть -- батч из изображений 28x28x1
def prepare_input(img):
    img = np.array(img, dtype=np.uint8)
    sx, sy = 345, 314 # координаты угла первой ячейки
    w, h = 111, 111 # размеры ячейки
    coords = [
        [sy, sx, h, w],
        [sy, sx+w+4, h, w],
        [sy, sx+2*(w+4), h, w],
        [sy, sx+4*(w+4), h, w],
        [sy, sx+5*(w+4), h, w],
        [sy, sx+6*(w+4), h, w],
        [sy, sx+8*(w+4), h, w],
        [sy, sx+9*(w+4), h, w],
        [sy, sx+11*(w+4), h, w],
        [sy, sx+12*(w+4), h, w],
    ]
    # Вырезаем изображения цифр из ячеек
    batch = []
    for cc in coords:
        batch.append(prepare_digit(img[
            cc[0]:cc[0]+cc[2],
            cc[1]:cc[1]+cc[3],
            ...]))
    return np.stack(batch, axis=0)

# Чтение изображения с диска
# Путь к изображению -- первый аргумент командной строки
img_fpath = sys.argv[1]
img = Image.open(img_fpath)

# Подготовка входных данных для нейронной сети
inp = prepare_input(img)

# Подготовка данных для HTTP запроса
request_data = json.dumps({
    "signature_name": "serving_default",
    "instances": inp.tolist()
})
headers = {"content-type": "application/json"}

# HTTP запрос на сервер
json_response = requests.post(
    'http://localhost:8501/v1/models/saved_model/versions/1:predict',
    data=request_data, headers=headers)

# Обработка JSON ответа
predictions = json.loads(json_response.text)['predictions']
digits = []
for p in predictions:
    digits.append(np.argmax(p))

# Печать результата распознавания
print('Recognized phone number:')
print('+7 ({}{}{}) {}{}{}-{}{}-{}{}'.format(
    digits[0], digits[1], digits[2], digits[3], digits[4],
    digits[5], digits[6], digits[7], digits[8], digits[9]))
